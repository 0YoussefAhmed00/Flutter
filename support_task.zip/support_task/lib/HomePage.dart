import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class HomePage  extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset("Images/flutter_task_image.jpg"),
            SizedBox(height: 50,),
            Padding(
              padding: const EdgeInsets.only(left: 50),
              child: Text("Safe Payment, Happy You!",style: TextStyle(
                fontSize: 20,
                color: Colors.black,

              ),),
            ),
            SizedBox(height: 30,),
            Padding(
              padding: const EdgeInsets.only(left: 20),
              child: Text("Create a fresh Virtual credit card for all your\n            shoppings and banking needs.",style: TextStyle(
                fontSize: 15,
                color: Colors.grey,
              )),
            ),
            SizedBox(height: 40,),
            Padding(
                padding: const EdgeInsets.only(left: 130,right: 130),
                child : ElevatedButton(
                  onPressed: () {
                  },
                  style: ElevatedButton.styleFrom(
                    primary: Color.fromRGBO(106,90,205, 1),
                    //increase size of button
                    padding: EdgeInsets.all(20),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.arrow_right_alt_outlined , size: 40),
                      SizedBox(width: 5),
                    ],
                  ),
                )
            )
          ],
        ),
      ),

      backgroundColor: Colors.white,
    );
  }
}